// Biblioteca do ProtoMax Arcade.
// Para adicionar um jogo: crie a pasta games/<id>/ com index.html e cover.jpg (proporção 3:4)
// e acrescente um bloco abaixo. orientation: "portrait", "landscape" ou "any".
window.PMX_GAMES = [
  {
    id: "geo-sagris",
    title: "Geo Sagris",
    subtitle: "Padrões da Criação",
    genre: "Puzzle · Geometria",
    desc: "Reproduza padrões da geometria sagrada só com compasso e régua, da Vesica Piscis ao Sri Yantra. 21 fases, modo livre e um Códice com as fontes de cada figura.",
    cover: "games/geo-sagris/cover.jpg",
    path: "games/geo-sagris/index.html",
    orientation: "portrait",
    accent: "#f0c76a"
  },
  {
    id: "linhagem-lunar",
    title: "Linhagem Lunar",
    subtitle: "Sete vidas, uma linhagem",
    genre: "Ação · Plataforma",
    desc: "Sete sonhos, sete mulheres da mesma linhagem, da Edimburgo de 1591 até hoje. Magia da lua, três familiares e um grimório com as fontes históricas de cada sonho.",
    cover: "games/linhagem-lunar/cover.jpg",
    path: "games/linhagem-lunar/index.html",
    orientation: "landscape",
    accent: "#9db8ff"
  }
];
