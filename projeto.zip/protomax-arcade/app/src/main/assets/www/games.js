// Biblioteca do ProtoMax Arcade.
// Para adicionar um jogo: crie a pasta games/<id>/ com index.html e cover.jpg (proporção 3:4)
// e acrescente um bloco abaixo. orientation: "portrait", "landscape" ou "any".
window.PMX_GAMES = [
  {
    id: "geo-sagris",
    title: "Geo Sagris",
    subtitle: "Padrões da Criação",
    genre: "Puzzle · Geometria",
    desc: "Reproduza padrões da geometria sagrada só com compasso e régua, da Vesica Piscis ao Sri Yantra. 21 fases, modo livre e um Códice com as fontes de cada figura.",
    cover: "games/geo-sagris/cover.jpg",
    path: "games/geo-sagris/index.html",
    orientation: "portrait",
    accent: "#f0c76a"
  },
  {
    id: "linhagem-lunar",
    title: "Linhagem Lunar",
    subtitle: "Sete vidas, uma linhagem",
    genre: "Ação · Plataforma",
    desc: "Sete sonhos, sete mulheres da mesma linhagem, da Edimburgo de 1591 até hoje. Magia da lua, três familiares e um grimório com as fontes históricas de cada sonho.",
    cover: "games/linhagem-lunar/cover.jpg",
    path: "games/linhagem-lunar/index.html",
    orientation: "landscape",
    accent: "#9db8ff"
  },
  {
    id: "miau-brawl",
    title: "Miau Brawl",
    subtitle: "Gatos contra ratos-robô",
    genre: "Briga · Roguelite",
    desc: "Briga de beco com gatos contra ratos-robô. Escolha Mingau, Sombra ou Bolota, suba de nível, monte sua build de habilidades e derrote o Rei Rato.",
    cover: "games/miau-brawl/cover.jpg",
    path: "games/miau-brawl/index.html",
    orientation: "landscape",
    accent: "#39ff7a"
  },
  {
    id: "paper-flight",
    title: "Paper Flight",
    subtitle: "Voe, atire e desvie",
    genre: "Tiro · Arcade",
    desc: "Pilote o aviãozinho de papel, atire e desvie dos inimigos de papel dobrado. Tem chefes, loja de retalhos e o voo infinito pra bater recorde.",
    cover: "games/paper-flight/cover.jpg",
    path: "games/paper-flight/index.html",
    orientation: "landscape",
    accent: "#ef5b3f"
  },
  {
    id: "aisle-rush",
    title: "Aisle Rush",
    subtitle: "Corrida de carrinhos de supermercado",
    genre: "Corrida",
    desc: "Corrida de carrinhos nos corredores do mercado: 18 pistas, rivais com história, itens de promoção, oficina e loja.",
    cover: "games/aisle-rush/cover.jpg",
    path: "games/aisle-rush/index.html",
    orientation: "landscape",
    accent: "#FFD100"
  }
];
